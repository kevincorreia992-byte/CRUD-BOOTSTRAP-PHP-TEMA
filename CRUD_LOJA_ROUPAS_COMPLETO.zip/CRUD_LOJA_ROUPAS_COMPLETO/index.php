<?php
require_once __DIR__ . '/config.php';
require_once DBAPI;
$db = open_database();
include HEADER_TEMPLATE;
?>
<header class="mb-4">
    <h1 class="page-title">Dashboard <span class="text-muted fs-5">/ Loja de Roupas</span></h1>
    <p class="text-secondary">Acesso rápido aos cadastros da loja.</p>
</header>
<?php show_flash(); ?>
<?php if ($db): close_database($db); ?>
    <div class="row g-3">
        <div class="col-6 col-md-4 col-lg-3"><a class="store-card" href="<?php echo e(BASEURL); ?>customers/add.php"><i class="fa-solid fa-user-plus"></i><span>Novo Cliente</span></a></div>
        <div class="col-6 col-md-4 col-lg-3"><a class="store-card" href="<?php echo e(BASEURL); ?>customers/index.php"><i class="fa-solid fa-users"></i><span>Gerenciar Clientes</span></a></div>
        <div class="col-6 col-md-4 col-lg-3"><a class="store-card" href="<?php echo e(BASEURL); ?>roupas/add.php"><i class="fa-solid fa-shirt"></i><span>Nova Roupa</span></a></div>
        <div class="col-6 col-md-4 col-lg-3"><a class="store-card" href="<?php echo e(BASEURL); ?>roupas/index.php"><i class="fa-solid fa-tags"></i><span>Gerenciar Roupas</span></a></div>
        <div class="col-6 col-md-4 col-lg-3"><a class="store-card" href="<?php echo e(BASEURL); ?>Usuarios/add.php"><i class="fa-solid fa-user-plus"></i><span>Novo Usuário</span></a></div>
        <div class="col-6 col-md-4 col-lg-3"><a class="store-card" href="<?php echo e(BASEURL); ?>Usuarios/index.php"><i class="fa-solid fa-user-gear"></i><span>Gerenciar Usuários</span></a></div>
    </div>
<?php else: ?>
    <div class="alert alert-danger"><strong>Não foi possível conectar ao banco de dados.</strong> Confira o MySQL e os dados do arquivo config.php.</div>
<?php endif; ?>
<?php include FOOTER_TEMPLATE; ?>

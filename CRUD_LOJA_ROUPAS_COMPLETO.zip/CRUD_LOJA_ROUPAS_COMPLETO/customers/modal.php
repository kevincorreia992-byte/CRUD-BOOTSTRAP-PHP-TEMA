<div class="modal fade" id="delete-modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
		<div class="modal-header">
			<h4 class="modal-title" id="modalLabel">Excluir Item</h4>
			<button type="button" class="btn btn-danger close" data-bs-dismiss="modal" aria-label="Fechar">
			<span aria-hidden="true"><i class="fas fa-times"></i></span></button>
		</div>
		<div class="modal-body">
			Deseja realmente excluir este item?
		</div>
		<div class="modal-footer">
			<a id="confirm" class="btn btn-primary" href="">Sim</a>
			<a id="cancel" class="btn btn-dark" data-bs-dismiss="modal">Não</a>
		</div>
		</div>
	</div>
</div>
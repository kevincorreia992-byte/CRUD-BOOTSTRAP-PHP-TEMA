<?php
require_once __DIR__ . '/functions.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Exclusão permitida apenas por POST.');
}
require_csrf();
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    flash('ID inválido para exclusão.', 'danger');
    redirect_to('index.php');
}
delete($id);

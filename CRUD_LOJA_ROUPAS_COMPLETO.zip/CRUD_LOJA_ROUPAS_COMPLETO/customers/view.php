<?php 
	include "functions.php"; 
	view($_GET['id']);
	include HEADER_TEMPLATE ; 
?>

<h2>Cliente <?php echo $customer["id"]; ?></h2>
<hr>

<?php if (!empty($_SESSION['message'])) : ?>
	<div class="alert alert-<?php echo $_SESSION['type']; ?>"><?php echo $_SESSION['message']; ?></div>
<?php endif; ?>

<dl class="row">

	<dt class="col-sm-2">Nome / Razão Social:</dt>
	<dd class="col-sm-10"><?php echo $customer['name']; ?></dd>

	<dt class="col-sm-2">CPF / CNPJ:</dt>
	<dd class="col-sm-10"><?php echo $customer['cpf_cnpj']; ?></dd> 

	<dt class="col-sm-2">Data de Nascimento:</dt>
	<dd class="col-sm-10"><?php echo $customer['birthdate']; ?></dd>
		
</dl>

<dl class="row">

    <dt class="col-sm-2">Endereço:</dt>
    <dd class="col-sm-10"><?php echo $customer['address']; ?></dd>

	<dt class="col-sm-2">Bairro:</dt>
	<dd class="col-sm-10"><?php echo $customer['hood']; ?></dd>

	<dt class="col-sm-2">CEP:</dt>
	<dd class="col-sm-10"><?php echo $customer['zip_code']; ?></dd>

	<dt class="col-sm-2">Data de Cadastro:</dt>
	<dd class="col-sm-10"><?php echo $customer['created']; ?></dd>

</dl>

<dl class="row">

    <dt class="col-sm-2">Cidade:</dt>
    <dd class="col-sm-10"><?php echo $customer['city']; ?></dd>

	<dt class="col-sm-2">Telefone:</dt>
	<dd class="col-sm-10"><?php echo $customer['phone']; ?></dd>

	<dt class="col-sm-2">Celular:</dt>
	<dd class="col-sm-10"><?php echo $customer['mobile']; ?></dd>

	<dt class="col-sm-2">UF:</dt>
	<dd class="col-sm-10"><?php echo $customer['state']; ?></dd>

	<dt class="col-sm-2">Inscrição Estadual:</dt>
	<dd class="col-sm-10"><?php echo $customer['ie']; ?></dd>

</dl>

<!--
<dl class="dl-horizontal">
	<dt>Nome / Razão Social:</dt>
	<dd><?php echo $customer['name']; ?></dd>

	<dt>CPF / CNPJ:</dt>
	<dd><?php echo $customer['cpf_cnpj']; ?></dd>

	<dt>Data de Nascimento:</dt>
	<dd><?php echo $customer['birthdate']; ?></dd>
</dl>

<dl class="dl-horizontal">
	<dt>Endereço:</dt>
	<dd><?php echo $customer['address']; ?></dd>

	<dt>Bairro:</dt>
	<dd><?php echo $customer['hood']; ?></dd>

	<dt>CEP:</dt>
	<dd><?php echo $customer['zip_code']; ?></dd>

	<dt>Data de Cadastro:</dt>
	<dd><?php echo $customer['created']; ?></dd>
</dl>

<dl class="dl-horizontal">
	<dt>Cidade:</dt>
	<dd><?php echo $customer['city']; ?></dd>

	<dt>Telefone:</dt>
	<dd><?php echo $customer['phone']; ?></dd>

	<dt>Celular:</dt>
	<dd><?php echo $customer['mobile']; ?></dd>

	<dt>UF:</dt>
	<dd><?php echo $customer['state']; ?></dd>

	<dt>Inscrição Estadual:</dt>
	<dd><?php echo $customer['ie']; ?></dd>
</dl>
-->

<div id="actions" class="row">
	<div class="col-md-12">
	  <a href="edit.php?id=<?php echo $customer['id']; ?>" class="btn btn-primary">Editar</a>
	  <a href="index.php" class="btn btn-default">Voltar</a>
	</div>
</div>

<?php include FOOTER_TEMPLATE; ?>
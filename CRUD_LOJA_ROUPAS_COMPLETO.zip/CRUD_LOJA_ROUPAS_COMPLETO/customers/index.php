<?php
    include "functions.php";
    index();
    include HEADER_TEMPLATE; 
?>

<header>
	<div class="row">
		<div class="col-sm-6">
			<h2>Clientes</h2>
		</div>
		<div class="col-sm-6 text-end h2">
	    	<a class="btn btn-primary" href="add.php"><i class="fa fa-plus"></i> Novo Cliente</a>
	    	<a class="btn btn-default" href="index.php"><i class="fa fa-refresh"></i> Atualizar</a>
	    </div>
	</div>
</header>

<?php show_flash(); ?>

<hr>

<div class="table-responsive"><table class="table table-hover">
<thead>
	<tr>
		<th>ID</th>
		<th width="30%">Nome</th>
		<th>CPF/CNPJ</th>
		<th>Telefone</th>
		<th>Atualizado em</th>
		<th class="actions text-center">Opções</th>
	</tr>
</thead>
<tbody>
    <?php if ($customers) : ?>
    <?php foreach ($customers as $customer) : ?>
        <tr>
            <td>
                <?php echo $customer["id"]; ?>
            </td>
            <td>
                <?php echo e($customer["name"]); ?>
            </td>
            <td>
                <?php echo e($customer["cpf_cnpj"]); ?>
            </td>
            <!-- td>00 0000-0000 colocar o telefone</td-->
            <td>
                <?php echo e($customer["mobile"]); ?>
            </td>
            <td>
                <?php 
                    $dt = new DateTime($customer["modified"], new DateTimeZone("-0300")); // Poderia ser America-SaoPaulo
                    echo $dt->format("d/m/Y - H:i:s");
                // echo $customer["modified"]; 
                ?>
            </td>
            <!--td class="actions text-end" -->
            <td class="actions text-end">
                <a href="view.php?id=<?php echo $customer["id"]; ?>" class="btn btn-sm btn-success">
                    <i class="fa-solid fa-eye"></i> Visualizar</a>
                <a href="edit.php?id=<?php echo $customer["id"]; ?>" class="btn btn-sm btn-warning">
                    <i class="fa-solid fa-pencil"></i> Editar</a>
                <a href="#" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#delete-modal" data-id="<?php echo (int)$customer["id"]; ?>">
                    <i class="fa-solid fa-trash"></i> Excluir
                </a>
            </td>
        </tr>
    <?php endforeach; ?>
    <?php else : ?>
        <tr>
            <td colspan="6">Nenhum registro encontrado.</td>
        </tr>
    <?php endif; ?>
</tbody>
</table></div>



<?php include FOOTER_TEMPLATE; ?>
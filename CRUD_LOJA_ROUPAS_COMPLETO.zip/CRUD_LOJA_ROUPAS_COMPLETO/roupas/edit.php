<?php 
  require_once('functions.php');
  edit();
  include(HEADER_TEMPLATE);
?>

<h2>Atualizar Roupa</h2>

<form action="edit.php?id=<?php echo $roupa['id']; ?>" method="post">
  <hr />
  <div class="row">
    <div class="form-group col-md-7">
      <label for="nome">Nome / Descrição</label>
      <input type="text" class="form-control" name="roupa['nome']" value="<?php echo $roupa['nome']; ?>" required>
    </div>

    <div class="form-group col-md-3">
      <label for="tamanho">Tamanho</label>
      <input type="text" class="form-control" name="roupa['tamanho']" value="<?php echo $roupa['tamanho']; ?>" required>
    </div>

    <div class="form-group col-md-2">
      <label for="cor">Cor</label>
      <input type="text" class="form-control" name="roupa['cor']" value="<?php echo $roupa['cor']; ?>" required>
    </div>
  </div>
  
  <div class="row">
    <div class="form-group col-md-3">
      <label for="preco">Preço (R$)</label>
      <input type="number" step="0.01" class="form-control" name="roupa['preco']" value="<?php echo $roupa['preco']; ?>" required>
    </div>

    <div class="form-group col-md-3">
      <label for="quantidade">Quantidade em Estoque</label>
      <input type="number" class="form-control" name="roupa['quantidade']" value="<?php echo $roupa['quantidade']; ?>" required>
    </div>
  </div>
  
  <div id="actions" class="row">
    <div class="col-md-12">
      <button type="submit" class="btn btn-primary">Salvar Alterações</button>
      <a href="index.php" class="btn btn-default">Cancelar</a>
    </div>
  </div>
</form>

<?php include(FOOTER_TEMPLATE); ?>
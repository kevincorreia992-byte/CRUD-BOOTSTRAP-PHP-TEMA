<?php 
  require_once('functions.php');
  add();
  include(HEADER_TEMPLATE);
?>

<h2>Nova Roupa</h2>

<form action="add.php" method="post">
  <hr />
  <div class="row">
    <div class="form-group col-md-7">
      <label for="nome">Nome / Descrição</label>
      <input type="text" class="form-control" name="roupa['nome']" required>
    </div>

    <div class="form-group col-md-3">
      <label for="tamanho">Tamanho</label>
      <input type="text" class="form-control" name="roupa['tamanho']" placeholder="Ex: P, M, G, 42" required>
    </div>

    <div class="form-group col-md-2">
      <label for="cor">Cor</label>
      <input type="text" class="form-control" name="roupa['cor']" required>
    </div>
  </div>
  
  <div class="row">
    <div class="form-group col-md-3">
      <label for="preco">Preço (R$)</label>
      <input type="number" step="0.01" class="form-control" name="roupa['preco']" required>
    </div>

    <div class="form-group col-md-3">
      <label for="quantidade">Quantidade em Estoque</label>
      <input type="number" class="form-control" name="roupa['quantidade']" required>
    </div>
  </div>
  
  <div id="actions" class="row">
    <div class="col-md-12">
      <button type="submit" class="btn btn-primary">Salvar</button>
      <a href="index.php" class="btn btn-default">Cancelar</a>
    </div>
  </div>
</form>

<?php include(FOOTER_TEMPLATE); ?>
<?php
    require_once('functions.php');
    index();
    include(HEADER_TEMPLATE);
?>

<header>
    <div class="row">
        <div class="col-sm-6">
            <h2>Roupas</h2>
        </div>
        <div class="col-sm-6 text-end">
            <a class="btn btn-primary" href="add.php"><i class="fa fa-plus"></i> Nova Roupa</a>
            <a class="btn btn-default" href="index.php"><i class="fa fa-refresh"></i> Atualizar</a>
        </div>
    </div>
</header>

<hr>
<?php show_flash(); ?>

<div class="table-responsive"><table class="table table-hover">
<thead>
    <tr>
        <th>ID</th>
        <th width="30%">Nome</th>
        <th>Tamanho</th>
        <th>Cor</th>
        <th>Preço</th>
        <th>Qtd</th>
        <th>Opções</th>
    </tr>
</thead>
<tbody>
<?php if ($roupas) : ?>
<?php foreach ($roupas as $r) : ?>
    <tr>
        <td><?php echo $r['id']; ?></td>
        <td><?php echo e($r['nome']); ?></td>
        <td><?php echo e($r['tamanho']); ?></td>
        <td><?php echo e($r['cor']); ?></td>
        <td>R$ <?php echo number_format($r['preco'], 2, ',', '.'); ?></td>
        <td><?php echo $r['quantidade']; ?></td>
        <td class="actions text-end">
            <a href="view.php?id=<?php echo $r['id']; ?>" class="btn btn-sm btn-success"><i class="fa fa-eye"></i> Visualizar</a>
            <a href="edit.php?id=<?php echo $r['id']; ?>" class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i> Editar</a>
            <a href="#" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#delete-modal" data-id="<?php echo (int)$r['id']; ?>">
                <i class="fa fa-trash"></i> Excluir
            </a>
        </td>
    </tr>
<?php endforeach; ?>
<?php else : ?>
    <tr>
        <td colspan="7">Nenhum registro encontrado.</td>
    </tr>
<?php endif; ?>
</tbody>
</table></div>

<?php include(FOOTER_TEMPLATE); ?>
<?php
require_once('functions.php');
include(HEADER_TEMPLATE);

if (isset($_GET['id'])) {
    view($_GET['id']);
} else {
    echo "<p>ID não informado!</p>";
}
?>


<h2>Roupa #<?php echo $roupa['id']; ?></h2>
<hr>

<dl class="dl-horizontal">
    <dt>Nome:</dt>
    <dd><?php echo $roupa['nome']; ?></dd>

    <dt>Tamanho:</dt>
    <dd><?php echo $roupa['tamanho']; ?></dd>

    <dt>Cor:</dt>
    <dd><?php echo $roupa['cor']; ?></dd>

    <dt>Preço:</dt>
    <dd>R$ <?php echo number_format($roupa['preco'], 2, ',', '.'); ?></dd>

    <dt>Estoque:</dt>
    <dd><?php echo $roupa['quantidade']; ?></dd>

    <dt>Cadastrado em:</dt>
    <dd><?php echo $roupa['created']; ?></dd>
</dl>

<div id="actions" class="row">
    <div class="col-md-12">
      <a href="edit.php?id=<?php echo $roupa['id']; ?>" class="btn btn-primary">Editar</a>
      <a href="index.php" class="btn btn-default">Voltar</a>
    </div>
</div>

<?php include(FOOTER_TEMPLATE); ?>
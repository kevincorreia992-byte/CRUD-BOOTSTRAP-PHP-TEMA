<?php
require_once('../config.php');
require_once(DBAPI);

$roupas = null;
$roupa = null;

/**
 * Listar Roupas
 */
function index() {
    global $roupas;
    $roupas = find_all('roupas');
}

/**
 * Cadastro de Roupas
 */
function add() {
    if (!empty($_POST['roupa'])) {
        $today = date_create('now', new DateTimeZone('America/Sao_Paulo'));
        $roupa = $_POST['roupa'];
        $roupa['modified'] = $today->format("Y-m-d H:i:s");
        $roupa['created'] = $today->format("Y-m-d H:i:s");
        
        save('roupas', $roupa);
        header('location: index.php');
    }
}

/**
 * Edição de Roupa
 */
function edit() {
    $today = date_create('now', new DateTimeZone('America/Sao_Paulo'));

    if (isset($_GET['id'])) {
        $id = $_GET['id'];

        if (isset($_POST['roupa'])) {
            $roupa = $_POST['roupa'];
            $roupa['modified'] = $today->format("Y-m-d H:i:s");

            update('roupas', $id, $roupa);
            header('location: index.php');
        } else {
            global $roupa;
            $roupa = find('roupas', $id);
        }
    } else {
        header('location: index.php');
    }
}

/**
 * Visualizar Roupa
 */
function view($id = null) {
    global $roupa;
    $roupa = find('roupas', $id);
}

/**
 * Exclusão de Roupa
 */
function delete($id = null) {
    global $roupa;
    $roupa = remove('roupas', $id);
    header('location: index.php');
}
?>
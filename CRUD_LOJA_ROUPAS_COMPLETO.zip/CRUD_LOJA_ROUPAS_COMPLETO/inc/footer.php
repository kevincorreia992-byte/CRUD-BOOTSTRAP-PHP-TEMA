</main>
<footer class="container border-top py-3">
    <small>&copy; <?php echo date('Y'); ?> · Loja de Roupas — Sistema de Gerenciamento de Clientes, Estoque e Usuários - Feito por Kevyn Correia, Enzo Barroso e Gustavo Domingues </small>
</footer>
<?php require_once MODAL_USUARIO_TEMPLATE; ?>
<script src="<?php echo e(BASEURL); ?>js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(BASEURL); ?>js/main.js"></script>
</body>
</html>

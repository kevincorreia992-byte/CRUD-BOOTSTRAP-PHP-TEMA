<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Loja de Roupas | Sistema de Gerenciamento</title>
    <link rel="stylesheet" href="<?php echo e(BASEURL); ?>css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(BASEURL); ?>css/all.min.css">
    <style>
        body { background: #f5f6fa; color: #273044; min-height: 100vh; }
        .navbar { background: #15233b !important; box-shadow: 0 4px 15px #0f172a12; }
        .navbar-brand { font-weight: 750; letter-spacing: .3px; }
        main.container { padding-top: 36px; padding-bottom: 35px; min-height: calc(100vh - 150px); }
        .btn-default { background: #fff; border: 1px solid #ced4da; color: #343a40; }
        .btn-default:hover { background: #e9ecef; border-color: #adb5bd; }
        .table { vertical-align: middle; }
        .table-responsive, .content-panel { background: #fff; border: 1px solid #e7eaf1; border-radius: 12px; box-shadow: 0 7px 22px #1b27400c; }
        .table-responsive { padding: 12px; }
        .form-control, .form-select { margin-bottom: 12px; }
        .form-group { margin-bottom: 8px; }
        .form-group label { margin-bottom: 6px; font-weight: 600; }
        .store-card { display: flex; min-height: 172px; flex-direction: column; justify-content: center; align-items: center; gap: 14px; border-radius: 15px; padding: 22px 15px; background: #fff; border: 1px solid #e6e9f2; text-align: center; box-shadow: 0 5px 17px #1b274010; text-decoration: none; color: #263c63; transition: transform .16s, box-shadow .16s; }
        .store-card:hover { transform: translateY(-3px); box-shadow: 0 10px 26px #1b274025; color: #0d6efd; }
        .store-card i { font-size: 45px; }
        .store-card span { font-size: 17px; font-weight: 650; }
        .avatar-sm { width: 46px; height: 46px; border-radius: 50%; object-fit: cover; background: #eef3fc; }
        .avatar-lg { width: 180px; height: 180px; border-radius: 13px; object-fit: cover; border: 1px solid #ddd; }
        .avatar-placeholder { display: inline-flex; align-items: center; justify-content: center; color: #687995; background: #eef3fc; }
        .avatar-sm.avatar-placeholder { font-size: 22px; }
        .avatar-lg.avatar-placeholder { font-size: 74px; }
        .actions .btn { margin: 2px; }
        .page-title { font-weight: 750; }
        footer { color: #677080; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(BASEURL); ?>index.php"><i class="fa-solid fa-shirt me-2"></i> Loja de Roupas</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarPrincipal" aria-controls="navbarPrincipal" aria-expanded="false" aria-label="Alternar navegação"><span class="navbar-toggler-icon"></span></button>
        <div id="navbarPrincipal" class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(BASEURL); ?>index.php">Dashboard</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Clientes</a>
                    <ul class="dropdown-menu"><li><a class="dropdown-item" href="<?php echo e(BASEURL); ?>customers/index.php">Gerenciar Clientes</a></li><li><a class="dropdown-item" href="<?php echo e(BASEURL); ?>customers/add.php">Novo Cliente</a></li></ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Roupas</a>
                    <ul class="dropdown-menu"><li><a class="dropdown-item" href="<?php echo e(BASEURL); ?>roupas/index.php">Gerenciar Roupas</a></li><li><a class="dropdown-item" href="<?php echo e(BASEURL); ?>roupas/add.php">Nova Roupa</a></li></ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Usuários</a>
                    <ul class="dropdown-menu"><li><a class="dropdown-item" href="<?php echo e(BASEURL); ?>Usuarios/index.php">Gerenciar Usuários</a></li><li><a class="dropdown-item" href="<?php echo e(BASEURL); ?>Usuarios/add.php">Novo Usuário</a></li></ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<main class="container">

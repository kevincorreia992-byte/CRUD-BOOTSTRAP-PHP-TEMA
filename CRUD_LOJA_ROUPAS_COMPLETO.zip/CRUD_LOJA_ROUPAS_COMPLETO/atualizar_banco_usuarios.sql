-- PARA BANCO QUE JÁ EXISTE:
-- Execute este script no phpMyAdmin, selecionando a base wda_crud.
-- Mantém os registros existentes de customers e roupas.
CREATE DATABASE IF NOT EXISTS `wda_crud` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `wda_crud`;

-- --------------------------------------------------------
-- Tabela de usuários / funcionários da loja de roupas
-- Foto: apenas o nome do arquivo; a imagem fica em Usuarios/fotos/.
-- Senha: hash gerado pelo password_hash do PHP (nunca salvar senha simples).
-- Campos do material PNG: id, nome, user, password e foto.
-- Campos do tema Loja de Roupas: email, telefone, cargo, setor e status.
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(120) NOT NULL,
  `user` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `telefone` varchar(20) DEFAULT NULL,
  `cargo` varchar(30) NOT NULL DEFAULT 'Vendedor',
  `setor` varchar(30) NOT NULL DEFAULT 'Vendas',
  `status` enum('Ativo','Inativo') NOT NULL DEFAULT 'Ativo',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_usuarios_login` (`user`),
  UNIQUE KEY `uk_usuarios_email` (`email`),
  KEY `idx_usuarios_nome` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

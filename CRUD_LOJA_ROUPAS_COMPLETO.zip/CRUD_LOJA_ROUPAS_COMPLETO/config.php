<?php
// Ajuste os dados conforme o MySQL do XAMPP.
date_default_timezone_set('America/Sao_Paulo');
define('DB_NAME', 'wda_crud');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

define('ABSPATH', __DIR__ . DIRECTORY_SEPARATOR);

$webPath = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
if (in_array(basename($webPath), ['customers', 'roupas', 'Usuarios'], true)) {
    $webPath = dirname($webPath);
}
define('BASEURL', rtrim($webPath, '/') . '/');
define('DBAPI', ABSPATH . 'inc/database.php');
define('HEADER_TEMPLATE', ABSPATH . 'inc/header.php');
define('FOOTER_TEMPLATE', ABSPATH . 'inc/footer.php');
define('MODAL_TEMPLATE', ABSPATH . 'customers/modal.php');
define('MODAL_ROUPA_TEMPLATE', ABSPATH . 'roupas/modal.php');
define('MODAL_USUARIO_TEMPLATE', ABSPATH . 'Usuarios/modal.php');

function e($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function flash(string $message, string $type = 'success'): void {
    $_SESSION['message'] = $message;
    $_SESSION['type'] = $type;
}

function show_flash(): void {
    if (empty($_SESSION['message'])) return;
    $type = in_array($_SESSION['type'] ?? '', ['success', 'danger', 'warning', 'info'], true)
        ? $_SESSION['type'] : 'info';
    echo '<div class="alert alert-' . e($type) . ' alert-dismissible fade show" role="alert">'
        . e($_SESSION['message'])
        . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button></div>';
    unset($_SESSION['message'], $_SESSION['type']);
}

function require_csrf(): void {
    if (!isset($_POST['csrf_token']) || !is_string($_POST['csrf_token'])
        || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
        http_response_code(403);
        exit('Solicitação inválida. Atualize a página e tente novamente.');
    }
}

function redirect_to(string $target): void {
    header('Location: ' . $target);
    exit;
}

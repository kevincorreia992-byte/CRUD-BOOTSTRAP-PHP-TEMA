document.addEventListener('DOMContentLoaded', function () {
    const modal = document.getElementById('delete-modal');
    if (modal) {
        modal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            if (!button) return;
            const id = button.getAttribute('data-id') || button.getAttribute('data-usuario') || button.getAttribute('data-roupa') || button.getAttribute('data-customer');
            const url = button.getAttribute('data-delete-url') || ('delete.php?id=' + encodeURIComponent(id));
            document.getElementById('delete-modal-title').textContent = 'Excluir registro #' + id;
            document.getElementById('delete-form').setAttribute('action', url);
        });
    }
    const upload = document.getElementById('foto');
    const preview = document.getElementById('imgPreview');
    if (upload && preview) {
        upload.addEventListener('change', function () {
            const file = upload.files && upload.files[0];
            if (!file) return;
            if (!file.type.startsWith('image/')) return;
            const reader = new FileReader();
            reader.onload = function (event) {
                if (preview.tagName.toLowerCase() === 'img') {
                    preview.src = event.target.result;
                } else {
                    const img = document.createElement('img');
                    img.id = 'imgPreview';
                    img.className = 'avatar-lg';
                    img.alt = 'Prévia da foto selecionada';
                    img.src = event.target.result;
                    preview.replaceWith(img);
                }
            };
            reader.readAsDataURL(file);
        });
    }
});

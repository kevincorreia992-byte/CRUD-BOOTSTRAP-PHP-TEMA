<!-- Janela compartilhada de confirmação de exclusão: clientes, roupas e usuários. -->
<div class="modal fade" id="delete-modal" tabindex="-1" aria-labelledby="delete-modal-title" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="delete-modal-title">Confirmar exclusão</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">Deseja realmente excluir este registro? Esta ação não pode ser desfeita.</div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form id="delete-form" method="post" action="">
                    <input type="hidden" name="csrf_token" value="<?php echo e($_SESSION['csrf_token']); ?>">
                    <button type="submit" class="btn btn-danger"><i class="fa-solid fa-trash me-1"></i> Sim, excluir</button>
                </form>
            </div>
        </div>
    </div>
</div>

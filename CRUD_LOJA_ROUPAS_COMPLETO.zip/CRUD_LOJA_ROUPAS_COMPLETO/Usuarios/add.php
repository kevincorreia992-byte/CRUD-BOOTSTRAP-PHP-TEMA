<?php
require_once __DIR__ . '/functions.php';
add();
include HEADER_TEMPLATE;
?>
<header class="mb-3"><h2 class="page-title">Novo Usuário</h2><p class="text-secondary">Cadastre um funcionário para a equipe da loja.</p></header>
<?php show_flash(); ?>
<?php include __DIR__ . '/form.php'; ?>
<?php include FOOTER_TEMPLATE; ?>

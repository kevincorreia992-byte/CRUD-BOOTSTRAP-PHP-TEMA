<?php
// Gestão de usuários da loja, conforme as referências PNG em /Usuarios.
require_once __DIR__ . '/../config.php';
require_once DBAPI;

$usuario = null;
$usuarios = [];
$termoPesquisa = '';

function usuarios_db(): mysqli {
    $db = open_database();
    if (!$db) {
        throw new RuntimeException('Não foi possível acessar o banco de dados.');
    }
    return $db;
}

function usuario_por_id(int $id): ?array {
    $db = usuarios_db();
    try {
        $stmt = $db->prepare('SELECT id, nome, `user`, email, telefone, cargo, setor, status, foto, created, modified FROM usuarios WHERE id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc() ?: null;
        $stmt->close();
        return $row;
    } finally {
        close_database($db);
    }
}

// Busca parametrizada: evita montar SQL com texto escrito pelo usuário.
function filter_usuarios(string $pesquisa): array {
    return filter('usuarios', $pesquisa);
}

function index(): void {
    global $usuarios, $termoPesquisa;
    $termoPesquisa = is_string($_GET['busca'] ?? null) ? trim($_GET['busca']) : '';
    try {
        if ($termoPesquisa !== '') {
            $usuarios = filter_usuarios($termoPesquisa);
        } else {
            $db = usuarios_db();
            try {
                $usuarios = $db->query('SELECT id, nome, `user`, email, telefone, cargo, setor, status, foto, created, modified FROM usuarios ORDER BY id DESC')->fetch_all(MYSQLI_ASSOC);
            } finally {
                close_database($db);
            }
        }
    } catch (Throwable $e) {
        $usuarios = [];
        flash('Não foi possível carregar usuários. Confira se a tabela usuarios foi criada no MySQL.', 'danger');
    }
}

function usuario_validar(array $data, bool $criacao): array {
    $nome = trim((string)($data['nome'] ?? ''));
    $login = trim((string)($data['user'] ?? ''));
    $email = trim((string)($data['email'] ?? ''));
    $telefone = trim((string)($data['telefone'] ?? ''));
    $cargo = trim((string)($data['cargo'] ?? ''));
    $setor = trim((string)($data['setor'] ?? ''));
    $status = trim((string)($data['status'] ?? 'Ativo'));
    $senha = (string)($data['password'] ?? '');
    $nomeLen = function_exists('mb_strlen') ? mb_strlen($nome, 'UTF-8') : strlen($nome);
    if ($nomeLen < 2 || $nomeLen > 120) {
        throw new InvalidArgumentException('Informe um nome de 2 a 120 caracteres.');
    }
    if (!preg_match('/^[A-Za-z0-9._-]{3,50}$/D', $login)) {
        throw new InvalidArgumentException('O login deve ter 3 a 50 caracteres, somente letras, números, ponto, hífen ou sublinhado.');
    }
    if ($email !== '' && (strlen($email) > 150 || !filter_var($email, FILTER_VALIDATE_EMAIL))) {
        throw new InvalidArgumentException('Informe um e-mail válido.');
    }
    if (strlen($telefone) > 20) {
        throw new InvalidArgumentException('O telefone deve ter até 20 caracteres.');
    }
    if (!in_array($cargo, ['Administrador', 'Gerente', 'Vendedor', 'Estoquista', 'Caixa'], true)) {
        throw new InvalidArgumentException('Selecione um cargo válido.');
    }
    if (!in_array($setor, ['Administração', 'Vendas', 'Estoque', 'Caixa', 'Atendimento'], true)) {
        throw new InvalidArgumentException('Selecione um setor válido.');
    }
    if (!in_array($status, ['Ativo', 'Inativo'], true)) {
        throw new InvalidArgumentException('Selecione um status válido.');
    }
    if (($criacao || $senha !== '') && strlen($senha) < 8) {
        throw new InvalidArgumentException('A senha precisa ter pelo menos 8 caracteres.');
    }
    return compact('nome', 'login', 'email', 'telefone', 'cargo', 'setor', 'status', 'senha');
}

// Devolve somente nome seguro de imagem já salva, para evitar caminhos arbitrários.
function usuario_foto_url(?string $foto): ?string {
    if (!$foto || !preg_match('/^[a-f0-9]{32}\.(jpg|png|webp)$/', $foto)) return null;
    return BASEURL . 'Usuarios/fotos/' . rawurlencode($foto);
}

function usuario_upload_foto(): ?string {
    if (!isset($_FILES['foto']) || $_FILES['foto']['error'] === UPLOAD_ERR_NO_FILE) return null;
    $file = $_FILES['foto'];
    if (!is_array($file) || $file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Não foi possível receber a foto. Verifique o envio.');
    }
    if ($file['size'] <= 0 || $file['size'] > 2 * 1024 * 1024) {
        throw new RuntimeException('A foto deve ter no máximo 2 MB.');
    }
    if (!is_uploaded_file($file['tmp_name'])) {
        throw new RuntimeException('Arquivo enviado não reconhecido.');
    }
    $info = @getimagesize($file['tmp_name']);
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    $tipos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!$info || !isset($tipos[$mime]) || $info['mime'] !== $mime) {
        throw new RuntimeException('Envie uma imagem JPG, PNG ou WebP válida.');
    }
    $nome = bin2hex(random_bytes(16)) . '.' . $tipos[$mime];
    $dir = __DIR__ . '/fotos/';
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        throw new RuntimeException('Não foi possível preparar a pasta fotos.');
    }
    if (!move_uploaded_file($file['tmp_name'], $dir . $nome)) {
        throw new RuntimeException('Não foi possível salvar a foto. Verifique as permissões da pasta.');
    }
    return $nome;
}

function usuario_remover_foto(?string $foto): void {
    if (!usuario_foto_url($foto)) return;
    $path = __DIR__ . '/fotos/' . $foto;
    if (is_file($path)) @unlink($path);
}

function usuario_erro(Throwable $e): void {
    if ($e instanceof mysqli_sql_exception && (int)$e->getCode() === 1062) {
        flash('O login ou e-mail informado já está cadastrado.', 'danger');
    } elseif ($e instanceof mysqli_sql_exception) {
        flash('Erro ao consultar o banco de dados. Verifique a configuração e a tabela usuarios.', 'danger');
    } elseif ($e instanceof InvalidArgumentException || $e instanceof RuntimeException) {
        flash($e->getMessage(), 'danger');
    } else {
        flash('Não foi possível completar a operação. Verifique o banco de dados.', 'danger');
    }
}

function add(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
    require_csrf();
    $foto = null;
    try {
        $data = usuario_validar((array)($_POST['usuario'] ?? []), true);
        $foto = usuario_upload_foto();
        $hash = password_hash($data['senha'], PASSWORD_DEFAULT);
        $agora = date('Y-m-d H:i:s');
        $db = usuarios_db();
        try {
            $sql = 'INSERT INTO usuarios (nome, `user`, password, email, telefone, cargo, setor, status, foto, created, modified) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
            $stmt = $db->prepare($sql);
            $email = $data['email'] !== '' ? $data['email'] : null;
            $stmt->bind_param('sssssssssss', $data['nome'], $data['login'], $hash, $email, $data['telefone'], $data['cargo'], $data['setor'], $data['status'], $foto, $agora, $agora);
            $stmt->execute();
            $stmt->close();
        } finally {
            close_database($db);
        }
        flash('Usuário cadastrado com sucesso.');
        redirect_to('index.php');
    } catch (Throwable $e) {
        usuario_remover_foto($foto);
        usuario_erro($e);
    }
}

function edit(): void {
    global $usuario;
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    if (!$id || $id < 1) redirect_to('index.php');
    try {
        $usuario = usuario_por_id($id);
        if (!$usuario) {
            flash('Usuário não encontrado.', 'warning');
            redirect_to('index.php');
        }
    } catch (Throwable $e) {
        usuario_erro($e);
        redirect_to('index.php');
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
    require_csrf();
    $novaFoto = null;
    try {
        $data = usuario_validar((array)($_POST['usuario'] ?? []), false);
        $novaFoto = usuario_upload_foto();
        $foto = $novaFoto ?? $usuario['foto'];
        $agora = date('Y-m-d H:i:s');
        $email = $data['email'] !== '' ? $data['email'] : null;
        $db = usuarios_db();
        try {
            if ($data['senha'] !== '') {
                $hash = password_hash($data['senha'], PASSWORD_DEFAULT);
                $stmt = $db->prepare('UPDATE usuarios SET nome=?, `user`=?, password=?, email=?, telefone=?, cargo=?, setor=?, status=?, foto=?, modified=? WHERE id=?');
                $stmt->bind_param('ssssssssssi', $data['nome'], $data['login'], $hash, $email, $data['telefone'], $data['cargo'], $data['setor'], $data['status'], $foto, $agora, $id);
            } else {
                $stmt = $db->prepare('UPDATE usuarios SET nome=?, `user`=?, email=?, telefone=?, cargo=?, setor=?, status=?, foto=?, modified=? WHERE id=?');
                $stmt->bind_param('sssssssssi', $data['nome'], $data['login'], $email, $data['telefone'], $data['cargo'], $data['setor'], $data['status'], $foto, $agora, $id);
            }
            $stmt->execute();
            $stmt->close();
        } finally {
            close_database($db);
        }
        if ($novaFoto !== null) usuario_remover_foto($usuario['foto']);
        flash('Usuário atualizado com sucesso.');
        redirect_to('index.php');
    } catch (Throwable $e) {
        usuario_remover_foto($novaFoto);
        usuario_erro($e);
    }
}

function view($id = null): void {
    global $usuario;
    $id = filter_var($id, FILTER_VALIDATE_INT);
    if (!$id || $id < 1) redirect_to('index.php');
    try {
        $usuario = usuario_por_id($id);
        if (!$usuario) {
            flash('Usuário não encontrado.', 'warning');
            redirect_to('index.php');
        }
    } catch (Throwable $e) {
        usuario_erro($e);
        redirect_to('index.php');
    }
}

function delete($id = null): void {
    $id = filter_var($id, FILTER_VALIDATE_INT);
    if (!$id || $id < 1) {
        flash('ID inválido.', 'danger');
        redirect_to('index.php');
    }
    try {
        $atual = usuario_por_id($id);
        if (!$atual) throw new InvalidArgumentException('Usuário não encontrado.');
        $db = usuarios_db();
        try {
            $stmt = $db->prepare('DELETE FROM usuarios WHERE id = ?');
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $stmt->close();
        } finally {
            close_database($db);
        }
        usuario_remover_foto($atual['foto']);
        flash('Usuário excluído com sucesso.');
    } catch (Throwable $e) {
        usuario_erro($e);
    }
    redirect_to('index.php');
}

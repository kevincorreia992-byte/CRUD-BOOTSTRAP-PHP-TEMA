<?php
require_once __DIR__ . '/functions.php';
view($_GET['id'] ?? null);
include HEADER_TEMPLATE;
?>
<header class="d-flex justify-content-between align-items-center mb-3"><h2 class="page-title">Usuário #<?php echo (int)$usuario['id']; ?></h2><a href="index.php" class="btn btn-default">Voltar à lista</a></header>
<?php show_flash(); ?>
<div class="content-panel p-4">
    <div class="row align-items-start">
        <div class="col-md-4 text-center mb-3">
            <?php if ($foto = usuario_foto_url($usuario['foto'])): ?>
                <img class="avatar-lg" src="<?php echo e($foto); ?>" alt="Foto do usuário">
            <?php else: ?><div class="avatar-lg avatar-placeholder mx-auto"><i class="fa-solid fa-user"></i></div><?php endif; ?>
        </div>
        <div class="col-md-8">
            <dl class="row">
                <dt class="col-sm-4">Nome completo</dt><dd class="col-sm-8"><?php echo e($usuario['nome']); ?></dd>
                <dt class="col-sm-4">Login</dt><dd class="col-sm-8"><?php echo e($usuario['user']); ?></dd>
                <dt class="col-sm-4">E-mail</dt><dd class="col-sm-8"><?php echo e($usuario['email'] ?: 'Não informado'); ?></dd>
                <dt class="col-sm-4">Telefone</dt><dd class="col-sm-8"><?php echo e($usuario['telefone'] ?: 'Não informado'); ?></dd>
                <dt class="col-sm-4">Cargo</dt><dd class="col-sm-8"><?php echo e($usuario['cargo']); ?></dd>
                <dt class="col-sm-4">Setor</dt><dd class="col-sm-8"><?php echo e($usuario['setor']); ?></dd>
                <dt class="col-sm-4">Status</dt><dd class="col-sm-8"><?php echo e($usuario['status']); ?></dd>
                <dt class="col-sm-4">Senha</dt><dd class="col-sm-8 text-secondary">Protegida — não é exibida</dd>
                <dt class="col-sm-4">Cadastrado em</dt><dd class="col-sm-8"><?php echo e(date('d/m/Y H:i', strtotime($usuario['created']))); ?></dd>
                <dt class="col-sm-4">Atualizado em</dt><dd class="col-sm-8"><?php echo e(date('d/m/Y H:i', strtotime($usuario['modified']))); ?></dd>
            </dl>
        </div>
    </div>
    <hr>
    <a class="btn btn-primary" href="edit.php?id=<?php echo (int)$usuario['id']; ?>"><i class="fa-solid fa-pen me-1"></i> Editar usuário</a>
    <a class="btn btn-default" href="index.php">Voltar</a>
</div>
<?php include FOOTER_TEMPLATE; ?>

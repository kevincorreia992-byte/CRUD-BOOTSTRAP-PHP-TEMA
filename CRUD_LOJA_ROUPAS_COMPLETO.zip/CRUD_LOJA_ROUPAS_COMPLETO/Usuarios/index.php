<?php
require_once __DIR__ . '/functions.php';
index();
include HEADER_TEMPLATE;
?>
<header class="row align-items-center mb-3">
    <div class="col-md-6"><h2 class="page-title">Gerenciar Usuários</h2><p class="text-secondary">Funcionários e acessos cadastrados na loja.</p></div>
    <div class="col-md-6 text-md-end">
        <a class="btn btn-primary" href="add.php"><i class="fa-solid fa-plus me-1"></i> Novo Usuário</a>
        <a class="btn btn-default" href="index.php"><i class="fa-solid fa-arrows-rotate me-1"></i> Atualizar</a>
    </div>
</header>
<?php show_flash(); ?>
<form action="index.php" method="get" class="mb-4">
    <div class="row g-2">
        <div class="col-md-5"><input type="search" name="busca" class="form-control mb-0" placeholder="Pesquisar nome, login, e-mail, cargo ou setor" value="<?php echo e($termoPesquisa); ?>" maxlength="100" aria-label="Pesquisar usuários"></div>
        <div class="col-auto"><button type="submit" class="btn btn-outline-primary"><i class="fa-solid fa-magnifying-glass me-1"></i> Consultar</button></div>
        <?php if ($termoPesquisa !== ''): ?><div class="col-auto"><a href="index.php" class="btn btn-default">Limpar</a></div><?php endif; ?>
    </div>
</form>
<div class="table-responsive">
    <table class="table table-hover align-middle">
        <thead><tr><th>ID</th><th>Foto</th><th>Nome</th><th>Login</th><th>Cargo / Setor</th><th>Status</th><th class="text-end">Opções</th></tr></thead>
        <tbody>
        <?php if ($usuarios): foreach ($usuarios as $u): ?>
            <tr>
                <td><?php echo (int)$u['id']; ?></td>
                <td>
                    <?php if ($foto = usuario_foto_url($u['foto'])): ?>
                        <img src="<?php echo e($foto); ?>" class="avatar-sm" alt="Foto de <?php echo e($u['nome']); ?>">
                    <?php else: ?><span class="avatar-sm avatar-placeholder"><i class="fa-solid fa-user"></i></span><?php endif; ?>
                </td>
                <td><?php echo e($u['nome']); ?></td>
                <td><?php echo e($u['user']); ?></td>
                <td><?php echo e($u['cargo']); ?><small class="d-block text-secondary"><?php echo e($u['setor']); ?></small></td>
                <td><span class="badge <?php echo $u['status'] === 'Ativo' ? 'bg-success' : 'bg-secondary'; ?>"><?php echo e($u['status']); ?></span></td>
                <td class="actions text-end text-nowrap">
                    <a class="btn btn-sm btn-success" href="view.php?id=<?php echo (int)$u['id']; ?>"><i class="fa-solid fa-eye"></i> Visualizar</a>
                    <a class="btn btn-sm btn-warning" href="edit.php?id=<?php echo (int)$u['id']; ?>"><i class="fa-solid fa-pen"></i> Editar</a>
                    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#delete-modal" data-id="<?php echo (int)$u['id']; ?>" data-delete-url="delete.php?id=<?php echo (int)$u['id']; ?>"><i class="fa-solid fa-trash"></i> Excluir</button>
                </td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="7" class="text-center py-4 text-secondary">Nenhum usuário encontrado.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php include FOOTER_TEMPLATE; ?>

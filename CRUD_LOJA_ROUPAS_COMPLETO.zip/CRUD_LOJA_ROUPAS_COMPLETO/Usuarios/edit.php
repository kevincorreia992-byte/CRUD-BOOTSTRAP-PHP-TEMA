<?php
require_once __DIR__ . '/functions.php';
edit();
include HEADER_TEMPLATE;
?>
<header class="mb-3"><h2 class="page-title">Editar Usuário #<?php echo (int)$usuario['id']; ?></h2></header>
<?php show_flash(); ?>
<?php include __DIR__ . '/form.php'; ?>
<?php include FOOTER_TEMPLATE; ?>

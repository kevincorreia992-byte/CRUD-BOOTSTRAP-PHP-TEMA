<?php
// Campos compartilhados entre cadastro e edição.
$dados = $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['usuario'])
    ? (array)$_POST['usuario'] : ($usuario ?? []);
$editar = isset($usuario) && !empty($usuario['id']);
$fotoUrl = $editar ? usuario_foto_url($usuario['foto'] ?? null) : null;
?>
<form action="<?php echo $editar ? 'edit.php?id=' . (int)$usuario['id'] : 'add.php'; ?>" method="post" enctype="multipart/form-data" class="content-panel p-4">
    <input type="hidden" name="csrf_token" value="<?php echo e($_SESSION['csrf_token']); ?>">
    <div class="row">
        <div class="form-group col-md-7">
            <label for="nome">Nome completo *</label>
            <input type="text" id="nome" class="form-control" name="usuario[nome]" maxlength="120" required value="<?php echo e($dados['nome'] ?? ''); ?>">
        </div>
        <div class="form-group col-md-5">
            <label for="login">Usuário (login) *</label>
            <input type="text" id="login" class="form-control" name="usuario[user]" maxlength="50" minlength="3" pattern="[A-Za-z0-9._-]+" title="Use letras, números, pontos, hífens e sublinhados" required value="<?php echo e($dados['user'] ?? ''); ?>">
        </div>
        <div class="form-group col-md-7">
            <label for="email">E-mail</label>
            <input type="email" id="email" class="form-control" name="usuario[email]" maxlength="150" value="<?php echo e($dados['email'] ?? ''); ?>">
        </div>
        <div class="form-group col-md-5">
            <label for="telefone">Telefone / WhatsApp</label>
            <input type="tel" id="telefone" class="form-control" name="usuario[telefone]" maxlength="20" placeholder="(15) 99999-9999" value="<?php echo e($dados['telefone'] ?? ''); ?>">
        </div>
        <div class="form-group col-md-5">
            <label for="senha">Senha <?php echo $editar ? '(deixe em branco para manter)' : '*'; ?></label>
            <input type="password" id="senha" class="form-control" name="usuario[password]" minlength="8" <?php echo $editar ? '' : 'required'; ?> autocomplete="new-password" placeholder="Pelo menos 8 caracteres">
        </div>
        <div class="form-group col-md-3">
            <label for="cargo">Cargo *</label>
            <select id="cargo" name="usuario[cargo]" class="form-select" required>
                <?php foreach (['Administrador', 'Gerente', 'Vendedor', 'Estoquista', 'Caixa'] as $opcao): ?>
                    <option value="<?php echo e($opcao); ?>" <?php echo ($dados['cargo'] ?? 'Vendedor') === $opcao ? 'selected' : ''; ?>><?php echo e($opcao); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group col-md-2">
            <label for="setor">Setor *</label>
            <select id="setor" name="usuario[setor]" class="form-select" required>
                <?php foreach (['Administração', 'Vendas', 'Estoque', 'Caixa', 'Atendimento'] as $opcao): ?>
                    <option value="<?php echo e($opcao); ?>" <?php echo ($dados['setor'] ?? 'Vendas') === $opcao ? 'selected' : ''; ?>><?php echo e($opcao); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group col-md-2">
            <label for="status">Status *</label>
            <select id="status" name="usuario[status]" class="form-select" required>
                <?php foreach (['Ativo', 'Inativo'] as $opcao): ?>
                    <option value="<?php echo e($opcao); ?>" <?php echo ($dados['status'] ?? 'Ativo') === $opcao ? 'selected' : ''; ?>><?php echo e($opcao); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <div class="row align-items-center mb-3">
        <div class="col-md-7 form-group">
            <label for="foto">Foto do usuário (JPG, PNG ou WebP, até 2 MB)</label>
            <input id="foto" type="file" accept="image/jpeg,image/png,image/webp" name="foto" class="form-control">
            <small class="text-secondary">Opcional. <?php echo $editar ? 'Se não enviar outra foto, a atual será mantida.' : 'Você pode adicionar uma foto agora ou depois.'; ?></small>
        </div>
        <div class="col-md-5 text-center">
            <label class="d-block">Pré-visualização</label>
            <?php if ($fotoUrl): ?>
                <img id="imgPreview" class="avatar-lg" src="<?php echo e($fotoUrl); ?>" alt="Foto atual do usuário">
            <?php else: ?>
                <div id="imgPreview" class="avatar-lg avatar-placeholder mx-auto"><i class="fa-solid fa-user"></i></div>
            <?php endif; ?>
        </div>
    </div>
    <hr>
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk me-1"></i> <?php echo $editar ? 'Salvar alterações' : 'Cadastrar usuário'; ?></button>
    <a href="index.php" class="btn btn-default">Cancelar</a>
</form>

<?php
require_once __DIR__ . '/functions.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('A exclusão deve ser confirmada pelo formulário.');
}
require_csrf();
delete($_GET['id'] ?? null);
